//
//  CustomCellQuiz.swift
//  GitHelp
//
//  Created by Andrew on 11/26/17.
//  Copyright © 2017 GitHelp. All rights reserved.
//

import UIKit

class CustomCellQuiz: UICollectionViewCell {
    
    @IBOutlet weak var myLabel: UILabel!
    
}

