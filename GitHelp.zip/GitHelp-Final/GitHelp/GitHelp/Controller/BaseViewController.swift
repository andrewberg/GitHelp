//
//  Extensions.swift
//  GitHelp
//
//  Created by Jared on 11/9/17.
//  Copyright © 2017 GitHelp. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {
    
    let bgColor: UIColor = UIColor(red: 42.0/255.0, green: 62.0/255.0, blue: 68.0/255.0, alpha: 1.0)
    let cellId = "cellId"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
