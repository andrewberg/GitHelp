//
//  CustomCell.swift
//  GitHelp
//
//  Created by Jared on 11/7/17.
//  Copyright © 2017 GitHelp. All rights reserved.
//

import UIKit

class CustomCell: UICollectionViewCell {
    
    @IBOutlet weak var myLabel: UILabel!
    
}
