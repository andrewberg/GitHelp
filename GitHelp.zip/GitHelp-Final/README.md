https://github.com/andrewberg/GitHelp-Backend

Easiest guide to follow for both front and backend if you need contact me @ andrewberg@pobox.com

https://github.com/andrewberg/GitHelp